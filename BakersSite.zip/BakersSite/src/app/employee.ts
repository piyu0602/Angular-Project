export class Employee {
  id: number | undefined;
  name: string | undefined;
  password: string | undefined;
  address: string | undefined;
  active: boolean | undefined;
}
