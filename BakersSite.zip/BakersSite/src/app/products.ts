export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  imageUrls: string;
}

export const products = [
  {
    id: 1,
    name: 'Cakes',
    price: 799,
    description: 'Freshly baked cakes that would enlighten your tastebuds.',
    imageUrls: 'assets/images/Cake.jpg',
  },
  {
    id: 2,
    name: 'Pastries',
    price: 149,
    description: 'Make the moments memorable with these little cutties...',
    imageUrls: 'assets/images/pastries.jpg',
  },
  {
    id: 3,
    name: 'Donuts',
    price: 199,
    description: 'And its the doughs drenched in happiness.',
    imageUrls: 'assets/images/donut.jpg',
  },
  {
    id: 4,
    name: 'Croissants',
    price: 229,
    description: 'Just grab through those puff of layers...',
    imageUrls: 'assets/images/Croissant.jpg',
  },
  {
    id: 5,
    name: 'Cookies',
    price: 49,
    description: 'Would never say No to these small delights..',
    imageUrls: 'assets/images/cookies.jpg',
  },
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
